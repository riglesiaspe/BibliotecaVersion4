import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { emitDistinctChangesOnlyDefaultValue } from '@angular/compiler/src/core';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {

  id;
  grado;
  listacursosgrado;

  @Input() curso;
  
  constructor( private bibliotecaService: BibliotecaService,
    private route: ActivatedRoute,
    private location: Location ) { }

    @Output() recargar = new EventEmitter();

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id']; //para obtener el parametro id que había pasado en la URL

    //this.grado=this.bibliotecaService.obtenerGrado(this.id);
    //en principio esta función ya no serviría, aunque si necesito pasarle el id para guardarlo peor podría hacerlo en la otra función
    /*
    this.bibliotecaService.obtenerGrado(this.id)
    .subscribe( grado => {
      this.grado = grado.payload.data()
      });
    */
    



    //this.listacursosgrado=this.bibliotecaService.obtenerCursosGrado(this.grado);

/*
    this.bibliotecaService.obtenerCursosGrado(this.id)
    .subscribe( cursos => {
      this.listacursosgrado = cursos.map (c => {
        return {
          id: c.payload.doc.id,
          ...c.payload.doc.data()
        };
      });
    });
    */
    this.bibliotecaService.obtenerCursosGrado(this.id)
    .subscribe( cursos => {
      this.listacursosgrado = cursos.data;
      });
  }



  eliminarCurso(curso){
    this.bibliotecaService.eliminarCurso(curso)
    .subscribe( (data:any) => {console.log(data.message)
    this.recargar.emit();
    } )
  }


  actualizarCurso(nuevoCurso, id){
    this.bibliotecaService.modificarCurso(nuevoCurso.value, id)
    .subscribe( data=>{console.log('curso modificado correctamente')
    this.recargar.emit();
    nuevoCurso.value="";
  } )
  }



  
  actualizarCursos(){
    this.bibliotecaService.obtenerCursosGrado(this.id)
    .subscribe( cursos => {
    this.listacursosgrado = cursos.data;
    });
  }

}
