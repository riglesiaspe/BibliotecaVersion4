import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';


@Component({
  selector: 'app-facultad-nueva',
  templateUrl: './facultad-nueva.component.html',
  styleUrls: ['./facultad-nueva.component.css']
})
export class FacultadNuevaComponent implements OnInit {

  @Output() recargar = new EventEmitter();
  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }
  anadirFacultad(facultad, id){
    this.bibliotecaService.anadirFacultad(facultad.value, id.value)
    .subscribe( data=>{console.log('facultad añadida correctamente')
    this.recargar.emit();
    facultad.value="";
    id.value="";
  } )
  }


}
