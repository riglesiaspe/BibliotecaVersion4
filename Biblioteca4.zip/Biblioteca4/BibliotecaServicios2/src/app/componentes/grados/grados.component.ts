import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { emitDistinctChangesOnlyDefaultValue } from '@angular/compiler/src/core';


@Component({
  selector: 'app-grados',
  templateUrl: './grados.component.html',
  styleUrls: ['./grados.component.css']
})
export class GradosComponent implements OnInit {

  id;
  facultad;
  listagrados;
  @Input() grado;

  constructor( private bibliotecaService: BibliotecaService,
               private route: ActivatedRoute,
               private location: Location ) { }

  @Output() recargar = new EventEmitter();
  ngOnInit(): void {
    this.id=this.route.snapshot.params['id']; //para obtener el parametro id que había pasado en la URL
    
    //this.id=this.route.snapshot.params['_id']; 
    //this.facultad=this.bibliotecaService.obtenerFacultad(this.id);
    /*
    this.bibliotecaService.obtenerFacultad(this.id)
    .subscribe( facultad => {
      this.facultad = facultad.payload.data()
      });
    */

    //this.listagrados=this.bibliotecaService.obtenerGrados(this.facultad);

    /*
    this.bibliotecaService.obtenerGrados(this.id)
    .subscribe( grados => {
      this.listagrados = grados.map (g => {
        return {
          id: g.payload.doc.id,
          ...g.payload.doc.data()
        };
      });
    });
*/


this.bibliotecaService.obtenerGrados(this.id)
    .subscribe( grados => {
      this.listagrados = grados.data;
      });
  }
  
  eliminarGrado(grado){
    this.bibliotecaService.eliminarGrado(grado)
    .subscribe( (data:any) => {console.log(data.message)
    this.recargar.emit();
    } )
  }


  actualizarGrado(nuevoGrado, id){
    this.bibliotecaService.modificarGrado(nuevoGrado.value, id)
    .subscribe( data=>{console.log('grado modificado correctamente')
    this.recargar.emit();
    nuevoGrado.value="";
  } )
  }

  



  actualizarGrados(){
    this.bibliotecaService.obtenerGrados(this.id)
    .subscribe( grados => {
      this.listagrados = grados.data;
    });
  }


}
