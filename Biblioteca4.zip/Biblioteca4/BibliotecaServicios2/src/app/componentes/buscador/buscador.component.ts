import { Component, OnInit } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-buscador',
  templateUrl: './buscador.component.html',
  styleUrls: ['./buscador.component.css']
})
export class BuscadorComponent implements OnInit {

  constructor(private $asignaturas: BibliotecaService) { }

  asignatura;

  ngOnInit(): void {
  }

  
  buscarAsignatura(asignaturaBuscada){
    /*
    this.$asignaturas.buscarAsignatura(asignaturaBuscada.value)
    .subscribe( infoAsignatura => {
      this.asignatura = infoAsignatura;
      console.log(infoAsignatura);
      console.log(this.asignatura.asignatura);
      
    })
    */
    
  }
  


  /*
  buscarAsignatura(asignaturaBuscada){
    this.bibliotecaService.buscarAsignatura(asignaturaBuscada);
  }
  */


}
