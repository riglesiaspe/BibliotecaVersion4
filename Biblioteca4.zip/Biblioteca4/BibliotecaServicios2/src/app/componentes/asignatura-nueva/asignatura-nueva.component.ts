import { Component, OnInit , Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-asignatura-nueva',
  templateUrl: './asignatura-nueva.component.html',
  styleUrls: ['./asignatura-nueva.component.css']
})
export class AsignaturaNuevaComponent implements OnInit {

  @Output() recargar = new EventEmitter();
  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirAsignatura(asignatura, id){
    this.bibliotecaService.anadirAsignatura(asignatura.value, id.value)
    .subscribe( data=>{console.log('asignatura añadida')
    this.recargar.emit();
    asignatura.value="";
    id.value="";
  } )
  }

}
