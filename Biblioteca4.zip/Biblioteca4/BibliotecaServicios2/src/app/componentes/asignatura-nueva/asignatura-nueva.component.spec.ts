import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsignaturaNuevaComponent } from './asignatura-nueva.component';

describe('AsignaturaNuevaComponent', () => {
  let component: AsignaturaNuevaComponent;
  let fixture: ComponentFixture<AsignaturaNuevaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsignaturaNuevaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsignaturaNuevaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
