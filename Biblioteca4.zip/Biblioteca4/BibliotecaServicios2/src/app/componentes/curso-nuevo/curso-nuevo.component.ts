import { Component, OnInit , Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-curso-nuevo',
  templateUrl: './curso-nuevo.component.html',
  styleUrls: ['./curso-nuevo.component.css']
})
export class CursoNuevoComponent implements OnInit {

  @Output() recargar = new EventEmitter();
  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirCurso(curso, id){
    this.bibliotecaService.anadirCurso(curso.value, id.value)
    .subscribe( data=>{console.log('curso añadido')
    this.recargar.emit();
    curso.value="";
    id.value="";
  } )
  }

}
