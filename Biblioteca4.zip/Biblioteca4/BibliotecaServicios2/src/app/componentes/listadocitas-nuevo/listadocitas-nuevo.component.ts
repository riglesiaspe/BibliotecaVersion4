import { Component, OnInit , Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-listadocitas-nuevo',
  templateUrl: './listadocitas-nuevo.component.html',
  styleUrls: ['./listadocitas-nuevo.component.css']
})
export class ListadocitasNuevoComponent implements OnInit {

  @Output() recargar = new EventEmitter();
  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }

  anadirLista(name, id, url, ejemplares){
    this.bibliotecaService.anadirLista(name.value,id.value, url.value, ejemplares.value)
    .subscribe( data=>{console.log('lista añadida')
    this.recargar.emit();
    name.value="";
    id.value="";
    ejemplares.value="";
    url.value="";
  } )
}

}
