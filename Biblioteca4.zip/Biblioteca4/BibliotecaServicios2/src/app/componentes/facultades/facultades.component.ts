import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-facultades',
  templateUrl: './facultades.component.html',
  styleUrls: ['./facultades.component.css']
})
export class FacultadesComponent implements OnInit {

  listaFacultades;
  @Input() facultad;

  constructor( private bibliotecaService: BibliotecaService) { }

  @Output() recargar = new EventEmitter();
  ngOnInit(): void {
   // this.listaFacultades=this.bibliotecaService.obtenerFacultades();
  this.bibliotecaService.obtenerFacultades()
  .subscribe( facultades => {
    this.listaFacultades = facultades.data;
  });
  }

  eliminarFacultad(facultad){
    this.bibliotecaService.eliminarFacultad(facultad)
    .subscribe( (data:any) => {console.log(data.message)
    this.recargar.emit();
    } )
  }

  /*
  actualizarFacultad(nuevaFacultad){
    this.bibliotecaService.modificarFacultad(nuevaFacultad)
    .subscribe( (data:any) => {console.log(data.message)
      this.recargar.emit();
    })
  }
  */

  actualizarFacultad(nuevaFacultad, id){
    this.bibliotecaService.modificarFacultad(nuevaFacultad.value, id)
    .subscribe( data=>{console.log('facultad modificada correctamente')
    this.recargar.emit();
    nuevaFacultad.value="";
  } )
  }

  actualizarFacultades(){
    this.bibliotecaService.obtenerFacultades()
    .subscribe( facultades => {
      this.listaFacultades = facultades.data;
    });
  }

}
