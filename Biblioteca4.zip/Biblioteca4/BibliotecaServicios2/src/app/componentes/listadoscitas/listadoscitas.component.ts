import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { emitDistinctChangesOnlyDefaultValue } from '@angular/compiler/src/core';


@Component({
  selector: 'app-listadoscitas',
  templateUrl: './listadoscitas.component.html',
  styleUrls: ['./listadoscitas.component.css']
})
export class ListadoscitasComponent implements OnInit {

  id;
  asignatura;
  listaslistadoscitas;

  @Input() listadocitas;

  constructor( private bibliotecaService: BibliotecaService,
    private route: ActivatedRoute,
    private location: Location ) { }

    @Output() recargar = new EventEmitter();
  ngOnInit(): void {
    this.id=this.route.snapshot.params['id']; //para obtener el parametro codigo que había pasado en la URL de cada asignatura

    //this.asignatura=this.bibliotecaService.obtenerAsignatura(this.codigo);
    

    /*
      this.bibliotecaService.obtenerAsignatura(this.id)
      .subscribe( asignatura => {
        this.asignatura = asignatura.payload.data()
        });
      
    */
  
  
      //this.listaslistadoscitas=this.bibliotecaService.obtenerListadoscitas(this.asignatura);
  
  /*
      this.bibliotecaService.obtenerListadoscitas(this.id)
      .subscribe( listadoscitas => {
        this.listaslistadoscitas = listadoscitas.map (l => {
          return {
            id: l.payload.doc.id,
            ...l.payload.doc.data()
          };
        });
      });
      */
      this.bibliotecaService.obtenerListadoscitas(this.id)
      .subscribe( listados => {
        this.listaslistadoscitas = listados.data;
        });
    }


    eliminarLista(lista){
      this.bibliotecaService.eliminarLista(lista)
      .subscribe( (data:any) => {console.log(data.message)
      this.recargar.emit();
      } )
    }
  
  
    actualizarLista(nuevaLista, id){
      this.bibliotecaService.modificarLista(nuevaLista.value, id)
      .subscribe( data=>{console.log('lista modificada correctamente')
      this.recargar.emit();
      nuevaLista.value="";
    } )
    }
  
  
  
    
    actualizarListas(){
      this.bibliotecaService.obtenerListadoscitas(this.id)
      .subscribe( listas => {
      this.listaslistadoscitas = listas.data;
      });
    }

  }


