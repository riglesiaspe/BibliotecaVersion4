import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BibliotecaService } from 'src/app/servicios/biblioteca.service';

@Component({
  selector: 'app-grado-nuevo',
  templateUrl: './grado-nuevo.component.html',
  styleUrls: ['./grado-nuevo.component.css']
})
export class GradoNuevoComponent implements OnInit {

  @Output() recargar = new EventEmitter();
  constructor(private bibliotecaService: BibliotecaService) { }

  ngOnInit(): void {
  }



  anadirGrado(grado, id){
    this.bibliotecaService.anadirGrado(grado.value, id.value)
    .subscribe( data=>{console.log('grado añadido')
    this.recargar.emit();
    grado.value="";
    id.value="";
  } )
  }

}
