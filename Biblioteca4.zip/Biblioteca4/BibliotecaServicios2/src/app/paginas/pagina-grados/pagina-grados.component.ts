import { Component, OnInit , ViewChild} from '@angular/core';

import { GradosComponent } from 'src/app/componentes/grados/grados.component';

@Component({
  selector: 'app-pagina-grados',
  templateUrl: './pagina-grados.component.html',
  styleUrls: ['./pagina-grados.component.css']
})
export class PaginaGradosComponent implements OnInit {

  @ViewChild(GradosComponent) child:GradosComponent;
  constructor() { }

  ngOnInit(): void {
  }

  recargar(){
    this.child.actualizarGrados();
  }

}
