import { Component, OnInit, ViewChild } from '@angular/core';
import { FacultadesComponent } from 'src/app/componentes/facultades/facultades.component';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  @ViewChild(FacultadesComponent) child:FacultadesComponent;
  constructor() { }

  ngOnInit(): void {
  }

  recargar(){
    this.child.actualizarFacultades();
  }

}
