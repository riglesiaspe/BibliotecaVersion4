import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginaAsignaturasComponent } from './pagina-asignaturas.component';

describe('PaginaAsignaturasComponent', () => {
  let component: PaginaAsignaturasComponent;
  let fixture: ComponentFixture<PaginaAsignaturasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaginaAsignaturasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginaAsignaturasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
