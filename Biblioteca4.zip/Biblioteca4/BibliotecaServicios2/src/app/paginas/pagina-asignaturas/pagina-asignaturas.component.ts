import { Component, OnInit, ViewChild } from '@angular/core';

import { AsignaturasComponent } from 'src/app/componentes/asignaturas/asignaturas.component';

@Component({
  selector: 'app-pagina-asignaturas',
  templateUrl: './pagina-asignaturas.component.html',
  styleUrls: ['./pagina-asignaturas.component.css']
})
export class PaginaAsignaturasComponent implements OnInit {

  @ViewChild(AsignaturasComponent) child:AsignaturasComponent;
  constructor() { }

  ngOnInit(): void {
  }

  recargar(){
    this.child.actualizarAsignaturas();
  }

}
