import { Component, OnInit , ViewChild} from '@angular/core';

import { CursosComponent } from 'src/app/componentes/cursos/cursos.component';

@Component({
  selector: 'app-pagina-cursos',
  templateUrl: './pagina-cursos.component.html',
  styleUrls: ['./pagina-cursos.component.css']
})
export class PaginaCursosComponent implements OnInit {

  @ViewChild(CursosComponent) child:CursosComponent;
  constructor() { }

  ngOnInit(): void {
  }

  recargar(){
    this.child.actualizarCursos();
  }
}
