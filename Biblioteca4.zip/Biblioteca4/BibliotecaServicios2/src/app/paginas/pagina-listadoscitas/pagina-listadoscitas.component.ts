import { Component, OnInit, ViewChild } from '@angular/core';

import { ListadoscitasComponent } from 'src/app/componentes/listadoscitas/listadoscitas.component';

@Component({
  selector: 'app-pagina-listadoscitas',
  templateUrl: './pagina-listadoscitas.component.html',
  styleUrls: ['./pagina-listadoscitas.component.css']
})
export class PaginaListadoscitasComponent implements OnInit {

  @ViewChild(ListadoscitasComponent) child:ListadoscitasComponent;
  constructor() { }

  ngOnInit(): void {
  }

  recargar(){
    this.child.actualizarListas();
  }

}
