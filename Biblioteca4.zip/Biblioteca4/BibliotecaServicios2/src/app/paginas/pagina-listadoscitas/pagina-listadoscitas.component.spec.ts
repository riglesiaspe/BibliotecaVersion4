import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginaListadoscitasComponent } from './pagina-listadoscitas.component';

describe('PaginaListadoscitasComponent', () => {
  let component: PaginaListadoscitasComponent;
  let fixture: ComponentFixture<PaginaListadoscitasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaginaListadoscitasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginaListadoscitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
