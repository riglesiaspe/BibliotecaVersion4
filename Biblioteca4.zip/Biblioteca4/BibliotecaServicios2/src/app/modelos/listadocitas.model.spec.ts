import { Listadocitas } from './listadocitas.model';

describe('Listadocitas', () => {
  it('should create an instance', () => {
    expect(new Listadocitas()).toBeTruthy();
  });
});
