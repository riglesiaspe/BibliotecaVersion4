import { Asignatura } from './asignatura.model';

describe('Asignatura', () => {
  it('should create an instance', () => {
    expect(new Asignatura()).toBeTruthy();
  });
});
