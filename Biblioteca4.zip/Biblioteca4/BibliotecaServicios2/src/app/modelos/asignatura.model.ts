import { ListadoscitasComponent } from "../componentes/listadoscitas/listadoscitas.component";

export class Asignatura {
    _id: string;
    id: string;
    asignatura: String;
    //listadoscitas: Listadocitas[];
}
