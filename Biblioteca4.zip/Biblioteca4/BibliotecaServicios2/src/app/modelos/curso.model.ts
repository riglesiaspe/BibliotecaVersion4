export class Curso {
    _id: string;
    id: string;
    curso: String;
    //asignaturas: Asignatura[];
}
