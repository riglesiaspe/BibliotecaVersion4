export class Facultad {
    _id: string;
    name: string;
    id: string;
    //grados: Grado[];
    //aquí tendría que poner que hay un array dentro??
}
