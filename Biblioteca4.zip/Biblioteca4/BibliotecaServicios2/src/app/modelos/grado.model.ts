export class Grado {
    _id: string;
    id: string;
    titulo: String;
    // cursos: Curso[];
}
