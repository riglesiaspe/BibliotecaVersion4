export class Listadocitas {
    id: String;
    _id : string;
    name: String;
    ejemplares: String;
    url: String;
}
