import { Injectable } from '@angular/core';

import { AngularFirestore } from '@angular/fire/firestore';
import { HttpClient } from '@angular/common/http';

import { Facultad } from '../modelos/facultad.model'; 
import { Grado } from '../modelos/grado.model';
import { Curso } from '../modelos/curso.model';
import { Asignatura } from '../modelos/asignatura.model';
import { Listadocitas } from '../modelos/listadocitas.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BibliotecaService {
  
/*
  facultades= [   {"id":"1","name":"Ciencias de la Salud"},
                  {"id":"2","name":"Comunicación"},
                  {"id":"3","name":"Derecho Canónico"},
                  {"id":"4","name":"Educación"},
                  {"id":"5","name":"Filosofía"},
                  {"id":"6","name":"Informática", "grados": [
                                                              {"id":"1","titulo":"Administración y Dirección de Empresas Tecnológicas", "cursos": [
                                                                                                                                                      {"curso": "primero", "asignaturas": [
                                                                                                                                                                                              {"codigo":"102511004" ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación e Impulso de Empresas. Comunicación en la empresa", "ejemplares":"6", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1222"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación e Impulso de Empresas. Impulso de empresas", "ejemplares":"6", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1720"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "Experto en Transformación en Impulso de Empresas. Transformación de empresas mediante el uso de la tecnología", "ejemplares":"3", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=809"},
                                                                                                                                                                                                                                                                                                          {"listadocitas": "F. Informática. ADET. Creación de empresas", "ejemplares":"3", "url":"https://koha.upsa.es/cgi-bin/koha/opac-shelves.pl?op=view&shelfnumber=1228"}
                                                                                                                                                                                                                                                                                                      ]},
                                                                                                                                                                                              {"codigo":"102520002" ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                                              {"codigo":"102511002" ,"asignatura": "Historia Económica"},
                                                                                                                                                                                              {"codigo":"102513004" ,"asignatura": "Inglés"},
                                                                                                                                                                                              {"codigo":"102511001" ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                                              {"codigo":"102511003" ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                                              {"codigo":"102520001" ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                                              {"codigo":"102512001" ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                                              {"codigo":"102511005" ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                                              {"codigo":"102511006" ,"asignatura": "Microeconomía"}
                                                                                                                                                                                          ]},
                                                                                                                                                      {"curso": "segundo"},
                                                                                                                                                      {"curso": "tercero"},
                                                                                                                                                      {"curso": "cuarto"}  
                                                                                                                                                  ] },
                                                              {"id":"2","titulo":"Ingeniería Informática", "cursos": [
                                                                                                                      {"curso": "primero"},
                                                                                                                      {"curso": "segundo"},
                                                                                                                      {"curso": "tercero"},
                                                                                                                      {"curso": "cuarto"}
                                                                                                                    ] },                  
                                                              {"id":"3","titulo":"Informática Móvil", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":401860001 ,"asignatura": "Tecnologías del lado del cliente: HTML5", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":401860002 ,"asignatura": "Tecnologías del lado del Servidor: Cloud computing"},
                                                                                                                                                                          {"codigo":401860003 ,"asignatura": "Desarrollo de aplicaciones iOS"},
                                                                                                                                                                          {"codigo":401860004 ,"asignatura": "Desarrollo de aplicaciones Android"},
                                                                                                                                                                          {"codigo":401860006 ,"asignatura": "Desarrollo de aplicaciones cross-platform"},
                                                                                                                                                                          {"codigo":401870001 ,"asignatura": "Prácticas en empresas"},
                                                                                                                                                                          {"codigo":401870002 ,"asignatura": "Tendencias en el desarrollo de apps"},
                                                                                                                                                                          {"codigo":401890001 ,"asignatura": "Trabajo Fin de Master"}
                                                                                                                                                                      ]}
                                                                                                                ]},
                                                              {"id":"4","titulo":"Dirección de Proyectos Informáticos y Servicios Tecnológicos", "cursos": [
                                                                                                                                                                          {"curso": "primero"},
                                                                                                                                                                          {"curso": "segundo"},
                                                                                                                                                                          {"curso": "tercero"},
                                                                                                                                                                          {"curso": "cuarto"}
                                                                                                                                                            ]},
                                                              {"id":"5","titulo":"Big Data y Analystics", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                    ]},
                                                              {"id":"6","titulo":"Programación iOS", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                ]},
                                                              {"id":"7","titulo":"Programación Android", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                  ]},
                                                              {"id":"8","titulo":"Big Data", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                        ]},
                                                              {"id":"9","titulo":"SAP Business One", "cursos": [
                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                    ]},
                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                      ]},
                                                                                                                                  {"curso": "segundo"},
                                                                                                                                  {"curso": "tercero"},
                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                ]},
                                                              {"id":"10","titulo":"Transformación e impulso de empresas", "cursos": [
                                                                                                                                                  {"curso": "primero", "asignaturas": [
                                                                                                                                                                                          {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                                                      {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                                                  ]},
                                                                                                                                                                                          {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                                                          {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                                                          {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                                                          {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                                                          {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                                                          {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                                                          {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                                                          {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                                                          {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                                                      ]},
                                                                                                                                                  {"curso": "segundo"},
                                                                                                                                                  {"curso": "tercero"},
                                                                                                                                                  {"curso": "cuarto"}  
                                                                                                                                    ]}
                                                            ] },
                  {"id":"7","name":"Psicología", "grados": [
                                                                {"id":1,"titulo":"PsicologiaPrueba", "cursos": [
                                                                                                                {"curso": "primero", "asignaturas": [
                                                                                                                                                        {"codigo":102511004 ,"asignatura": "Fundamentos de organización y gestión empresarial", "listadoscitas": [
                                                                                                                                                                                                                                                                    {"listadocitas": "ejemplocita1"},
                                                                                                                                                                                                                                                                    {"listadocitas": "ejemplocita2"}
                                                                                                                                                                                                                                                                ]},
                                                                                                                                                        {"codigo":102520002 ,"asignatura": "Fundamentos de programación"},
                                                                                                                                                        {"codigo":102511002 ,"asignatura": "Historia Económica"},
                                                                                                                                                        {"codigo":102513004 ,"asignatura": "Inglés"},
                                                                                                                                                        {"codigo":102511001 ,"asignatura": "Matemáticas:Álgebra y Análisis"},
                                                                                                                                                        {"codigo":102511003 ,"asignatura": "Derecho de Empresa"},
                                                                                                                                                        {"codigo":102520001 ,"asignatura": "Estadística y Probabilidad"},
                                                                                                                                                        {"codigo":102512001 ,"asignatura": "Hecho Religioso y Fe Cristiana"},
                                                                                                                                                        {"codigo":102511005 ,"asignatura": "Introducción a la Contabilidad"},
                                                                                                                                                        {"codigo":102511006 ,"asignatura": "Microeconomía"}
                                                                                                                                                    ]},
                                                                                                                {"curso": "segundo"},
                                                                                                                {"curso": "tercero"},
                                                                                                                {"curso": "cuarto"}  
                                                                                                          ]}
                                                          ]},
                  {"id":"8","name":"Teología"},
                  {"id":"9","name":"Enfermería y Fisioterapia"},
                  {"id":"10","name":"Ciencias del Seguro, Jurídicas y de la Empresa"}
];
*/

//bibliotecaservice-bb52a.web.app

  identificadorfacultad;
  identificadorgrado;
  identificadorcurso;
  identificadorasignatura;

  facultad;
  grado;
  curso;

  //listaFacultades: Facultad[];

  constructor( private http: HttpClient ) { }

  url = "https://biblioteca-six.vercel.app/api/facultades/";
  

  obtenerFacultades(): Observable<any>
  {
    //return this.facultades;
    //return this.firestore.collection('facultadesbiblioteca').snapshotChanges();
    return this.http.get(this.url);
  }

  anadirFacultad(facultad: Facultad, id){
    let nuevaFacultad = Object.assign( {}, {'name': facultad , 'id': id});
    //return this.firestore.collection('facultadesbiblioteca').add(nuevaFacultad);
    return this.http.post(this.url, nuevaFacultad);
  }

  eliminarFacultad(facultad:Facultad){
    return this.http.delete(this.url + facultad._id);
    //this.firestore.doc('facultadesbiblioteca/' + facultad.id).delete();
    // O también
    //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).delete(); esto se puede hacer en cualquier eliminar menos en 
    //el último de listados ya que no he guardado su identificador, entonces si necesitaria los modelos
    // this.firestore.collection('facultadesbiblioteca').doc(facultad.id).delete();
  }

  modificarFacultad(facultad:Facultad, id){
    let nuevaFacultad = Object.assign( {}, {'name': facultad, 'id': id });
    return this.http.put(this.url + id, nuevaFacultad);
  }

/* esto lo usaba cuando la bbdd era en local, como ahora esta en remoto en firebase, se hace directamente
  obtenerFacultad(id)
  {
    //this.identificadorfacultad = id;  //lo usaré para paginas más adelante, por ejemplo para conseguir los cursos de un grado concreto, de una facultad concreta, cuando voy de la pagina principal..
    //.. de facultades a una facultad concreta, me guardaba su id en la url, pero claro, en las siguientes paginas, la url cambia, y perdería el id para mostrar las asignaturas, cursos, grados, etc..
    //.. de una facultad con un id concreto, entonces, me estoy guardando este id en la variable identificadorfacultad de cara a futuras funciones.
    //return this.facultades.find( facultad => facultad.id === this.identificadorfacultad);
  
    this.identificadorfacultad = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).snapshotChanges();
  }
*/



  obtenerGrados(id): Observable<any>
  {
    //return facultad.grados;
    //yo antes ponia obtenerGrados(facultad),es decir le pasaba la facultad obtenida y a partir de ella pillaba sus grados,
    //pero ahora con firestone le puedo decir que ubique esa facultad directamente con su codigo
    this.identificadorfacultad = id; //necesito guardar este id en identificadorfaculad para otras funciones
  
    //return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).collection('grados').snapshotChanges();
    return this.http.get(this.url + this.identificadorfacultad + '/paginagrados');//no me funciona esta frase o al recoger los datos de la url
  }
/*
  anadirGrado(grado: Grado){
    let nuevoGrado = Object.assign( {}, {'titulo': grado });
    //return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad).collection('grados').add(nuevoGrado);
  }
  */

  anadirGrado(grado: Grado, id){
    let nuevoGrado = Object.assign( {}, {'titulo': grado , 'id': id});
    //return this.firestore.collection('facultadesbiblioteca').add(nuevaFacultad);
    //hasta aqui el grado con su id y titulo llega correctamente
    //console.log(nuevoGrado);
    //{titulo: "hola", id: "123"}
    //id: "123"
    //titulo: "hola"
    //__proto__: Object
    return this.http.post(this.url + this.identificadorfacultad + '/nuevogrado', nuevoGrado);
  }


  eliminarGrado(grado:Grado){
    return this.http.delete(this.url + this.identificadorfacultad + '/borrargrado/' + grado.id);
    //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + grado.id).delete();
  }


  modificarGrado(nuevogrado:Grado, id){
    let nuevoGrado = Object.assign( {}, {'titulo': nuevogrado, 'id': id });
    return this.http.put(this.url + this.identificadorfacultad + '/modificargrado', nuevoGrado);
  }


//esto lo quiero para obtener un grado concreto y así poder mostrar los cursos que tiene dentro, no confundir el id del grado con el id de la facultad determinada.
//en principio con firebase esta función ya quedaría obsoleta, por que puedo coger los cursos directamente sin pasar por esta función, aunque necesito el id
  /*
obtenerGrado(id)
  {
    //this.identificadorgrado = id;
    //this.facultad = this.obtenerFacultad(this.identificadorfacultad);
    //return this.facultad.grados.find( grado => grado.id === this.identificadorgrado);

    this.identificadorgrado = id;
    return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado).snapshotChanges();
  }
  */

  obtenerCursosGrado(id): Observable<any>
  {
    //return grado.cursos;   antes ponia en obtenerCursosGRado(grado) pero ya no es necesario porque puedo cogerlo directamente
    this.identificadorgrado = id;

    return this.http.get(this.url + this.identificadorfacultad + '/paginagrados/' + this.identificadorgrado + '/paginacursos');//no me funciona esta frase o al recoger los datos de la url

    //return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado).collection('cursos').snapshotChanges();
  }


  anadirCurso(curso: Curso, id){
    let nuevoCurso = Object.assign( {}, {'curso': curso , 'id': id});
    return this.http.post(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/nuevocurso', nuevoCurso);
  }


  eliminarCurso(curso:Curso){
    return this.http.delete(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/borrarcurso/' + curso.id);
    //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + grado.id).delete();
  }


  modificarCurso(nuevocurso:Curso, id){
    let nuevoCurso = Object.assign( {}, {'curso': nuevocurso, 'id': id });
    return this.http.put(this.url + this.identificadorfacultad + '/grado/' + this.identificadorgrado + '/modificarcurso', nuevoCurso);
  }
  


//ahora quiero obtener un curso del grado y facultad concretos, para así poder mostrar sus asignaturas
//en principio esta función solo sirve para pasar el identificador de la url porque ya esta obsoleta
/*
obtenerCurso(id)
{
  //this.identificadorcurso = id;
  //this.grado = this.obtenerGrado(this.identificadorgrado);
  //return this.grado.cursos.find( curso => curso.curso === this.identificadorcurso);

  this.identificadorcurso = id;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso).snapshotChanges();
}
*/

obtenerAsignaturas(id): Observable<any>
{
  //return curso.asignaturas; he quitado el obtenerAsignaturas(curso) ya no es necesario porque firestore lo hace directamente en una linea
  this.identificadorcurso = id;

  return this.http.get(this.url + this.identificadorfacultad + '/paginagrados/' + this.identificadorgrado + '/paginacursos/' + this.identificadorcurso + '/paginaasignaturas');//no me funciona esta frase o al recoger los datos de la url

  //return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso).collection('asignaturas').snapshotChanges();
}

anadirAsignatura(asignatura: Asignatura, id){
  let nuevaAsignatura = Object.assign( {}, {'asignatura': asignatura , 'id': id});
  return this.http.post(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/nuevasignatura', nuevaAsignatura);
}


eliminarAsignatura(asignatura:Asignatura){
  return this.http.delete(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/borrarasignatura/' + asignatura.id);
  //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + grado.id).delete();
}


modificarAsignatura(nuevasignatura:Asignatura, id){
  let nuevaAsignatura = Object.assign( {}, {'asignatura': nuevasignatura, 'id': id });
  return this.http.put(this.url + this.identificadorfacultad + '/grado/' + this.identificadorgrado + '/curso/' + this.identificadorcurso + '/modificarasignatura', nuevaAsignatura);
}

buscarAsignatura(asignaturaBuscada:string)
{
  //esto no me está funcionando porque al pasarle una ruta con la asignatura buscada realmente no me coge el elemento asignatura ya que en firebase la url
  //de un elemento se muestra a través del id automático creado, por lo tanto cuando hago el buscador con el subscribe  en buscador.ts no obtengo nada
//return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + asignaturaBuscada).snapshotChanges();
}



//quiero obtener una asignatura para una facultad, grado y curso determinada y así obtener sus listados de citas
/*
obtenerAsignatura(id)
{
  //this.curso = this.obtenerCurso(this.identificadorcurso);
  //return this.curso.asignaturas.find( asignatura => asignatura.codigo === codigo);
  this.identificadorasignatura = id;
  return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura).snapshotChanges();
}
*/

obtenerListadoscitas(id): Observable<any>
{
  this.identificadorasignatura = id;

  return this.http.get(this.url + this.identificadorfacultad + '/paginagrados/' + this.identificadorgrado + '/paginacursos/' + this.identificadorcurso + '/paginaasignaturas/' + this.identificadorasignatura + '/paginalistas');//no me funciona esta frase o al recoger los datos de la url

  //le he quitado asignatura a la funcion porque ya no es util
  //return asignatura.listadoscitas;
  //return this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura).collection('listadoscitas').snapshotChanges();
}



anadirLista(name: Listadocitas, id, url, ejemplares)
{
  let nuevaLista = Object.assign( {}, {'name': name , 'id': id, 'url': url, 'ejemplares': ejemplares});
  //return console.log(nuevaLista); si que muestra los datos que son, hasta aquí todo bien, es como si los envía mal
  //return console.log(this.identificadorasignatura, this.identificadorcurso, this.identificadorfacultad, this.identificadorgrado); tambien la ruta está bien
  //he comprobado y no es problema de la url o ejemplares
  return this.http.post(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura + '/nuevalista', nuevaLista);
}



eliminarLista(lista:Listadocitas){
  return this.http.delete(this.url + this.identificadorfacultad + '/grados/' + this.identificadorgrado + '/cursos/' + this.identificadorcurso + '/asignaturas/' + this.identificadorasignatura + '/borrarlistado/' + lista.id);
  //this.firestore.doc('facultadesbiblioteca/' + this.identificadorfacultad + '/grados/' + grado.id).delete();
}


modificarLista(nuevalista:Listadocitas, id){
  let nuevaLista = Object.assign( {}, {'name': nuevalista, 'id': id });
  return this.http.put(this.url + this.identificadorfacultad + '/grado/' + this.identificadorgrado + '/curso/' + this.identificadorcurso + '/asignatura/' + this.identificadorasignatura + '/modificarlista', nuevaLista);
}




}
