const express = require('express');
const bibliotecaService = require('../services/bibliotecaService');
/* GET home page. */
function bibliotecaAPI(app){
  const router = express.Router();


  app.use('/api/facultades', router);



  const BibliotecaService = new bibliotecaService();
  router.get('/', async (req, res, next) => {
    try {
      const facultades = await  BibliotecaService.getFacultades();
      res.status(200).json(
          {
              data: facultades,
              message: 'facultades devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.get('/:facultadId', async function (req, res, next) {
    const {facultadId}  = req.params; 
    try {
        const facultad = await BibliotecaService.getFacultad(facultadId);
        res.status(200).json({
            data: facultad,
            message: 'facultad devuelta'
        });
    } catch (err) {
        next(err);
    }

})

  router.post('/', async (req, res, next) => {
    const {body: facultad} = req;
    try {
      const nuevaFacultad = await  BibliotecaService.addFacultad(facultad);
      res.status(200).json(
          {
              data: nuevaFacultad,
              message: 'facultad añadida con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.put('/:facultadId', async function (req, res, next) {
    const  {facultadId}  = req.params;
    const  nuevaFacultad  = req.body; 

    try {
        const facultadActualizada = await BibliotecaService.actualizarFacultad(facultadId, nuevaFacultad);

        res.status(200).json({
            data: facultadActualizada,
            message: 'facultad actualizada con éxito'
        });
    } catch (err) {
        next(err);
    }

})

router.delete('/:facultadId', async function (req, res, next) {
    const  {facultadId}  = req.params;

    try {
        const facultadBorrada = await BibliotecaService.borrarFacultad(facultadId);

        res.status(200).json({
            data: facultadBorrada,
            message: 'facultad borrada con éxito'
        });
    } catch (err) {
        next(err);
    }

})




//para las funciones de grados

router.get('/:facultadId/paginagrados', async (req, res, next) => {
    //const  {facultadId}  = req.params.facultadId;
    //const  {facultadId}  = req.params(facultadId);
    const {facultadId} = req.params;

    try {
      const grados = await  BibliotecaService.getGrados(facultadId);
      res.status(200).json(
          {
              data: grados,
              message: 'grados devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.get('/:facultadId/getgrado/:gradoId', async function (req, res, next) {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 
    try {
        const grado = await BibliotecaService.getGrado(facultadId, gradoId);
        res.status(200).json({
            data: grado,
            message: 'grado devuelto'
        });
    } catch (err) {
        next(err);
    }
})


router.post('/:facultadId/nuevogrado', async(req, res, next) => {
    const {body: nuevoGrado} = req; 
    const {facultadId} = req.params;


    //lo creo yo por ahora artificialmente para hacer pruebas en servidor, luego tengo que borrar esto
    //const nuevoGrado = {titulo: "hola", id: "123"};
    //pero esto si tengo que hacerlo, para añadir un _id con el valor del id que venga en el body
    //y también se debe añadir un array donde se irán insertando los cursos en un futuro(no se si funcionará solo con poner eso así)
    const _id = nuevoGrado.id;
    nuevoGrado["_id"] = _id;
    nuevoGrado["cursos"] = ["grado a borrar"];

    try {
      const nuevogradoadd = await  BibliotecaService.addGrado(nuevoGrado, facultadId);
      res.status(200).json(
          {
              //data: nuevogradoadd,
              message: 'grado añadido correctamente',
              nuevogrado: nuevogradoadd
              //console: console.log(nuevoGrado),
              //gradonuevo: 'nuevoGrado',
              //consoleid: console.log(facultadId),
              //id: facultadId
          }
      )
    } catch (err){
        next(err);
    }
  });


  router.delete('/:facultadId/borrargrado/:gradoId', async function (req, res, next) { 
    const  {facultadId}  = req.params;
    const  {gradoId} =req.params;

    try {
        const gradoBorrado = await BibliotecaService.borrarGrado(facultadId, gradoId);

        res.status(200).json({
            data: gradoBorrado,
            message: 'grado borrada con éxito'
        });
    } catch (err) {
        next(err);
    }

})



router.put('/:facultadId/modificargrado', async function (req, res, next) {
    const {body: nuevoGrado} = req;
    const  {facultadId}  = req.params;
    //const nuevoGrado = {titulo: "adios", id: "123"};
    

    try {
        const gradoActualizado = await BibliotecaService.actualizarGrado(facultadId, nuevoGrado);

        res.status(200).json({
            data: gradoActualizado,
            message: 'grado actualizado con éxito'
        });
    } catch (err) {
        next(err);
    }

})





//para las funciones de cursos

router.get('/:facultadId/paginagrados/:gradoId/paginacursos', async (req, res, next) => {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 

    try {
      const cursos = await  BibliotecaService.getCursos(facultadId, gradoId);
      res.status(200).json(
          {
              data: cursos,
              message: 'cursos devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.get('/:facultadId/getgrado/:gradoId/getcurso/:cursoId', async function (req, res, next) {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 
    const {cursoId}  = req.params; 
    try {
        const curso = await BibliotecaService.getCurso(facultadId, gradoId, cursoId);
        res.status(200).json({
            data: curso,
            message: 'curso devuelto'
        });
    } catch (err) {
        next(err);
    }
})

router.post('/:facultadId/grados/:gradoId/nuevocurso', async(req, res, next) => { //poner get para porbar solo en servidor
    const {body: nuevoCurso} = req; //aquí debería de pasar el nombre del curso(curso) y el id
    const {facultadId} = req.params;
    const {gradoId} = req.params;


    //lo creo yo por ahora artificialmente para hacer pruebas en servidor, luego tengo que borrar esto
    //const nuevoCurso = {curso: "octavo", id: "12345"};
    //pero esto si tengo que hacerlo, para añadir un _id con el valor del id que venga en el body
    //y también se debe añadir un array donde se irán insertando los cursos en un futuro)
    const _id = nuevoCurso.id;
    nuevoCurso["_id"] = _id;
    nuevoCurso["asignaturas"] = ["asignatura a borrar"];

    try {
      const nuevocursoadd = await  BibliotecaService.addCurso(nuevoCurso, facultadId, gradoId);
      res.status(200).json(
          {
              //data: nuevogradoadd,
              message: 'grado añadido correctamente',
              nuevocurso: nuevocursoadd
              //console: console.log(nuevoGrado),
              //gradonuevo: 'nuevoGrado',
              //consoleid: console.log(facultadId),
              //id: facultadId
          }
      )
    } catch (err){
        next(err);
    }
  });



  router.delete('/:facultadId/grados/:gradoId/borrarcurso/:cursoId', async function (req, res, next) { 
    const  {facultadId}  = req.params;
    const  {gradoId} =req.params;
    const  {cursoId} =req.params;

    try {
        const cursoBorrado = await BibliotecaService.borrarCurso(facultadId, gradoId, cursoId);

        res.status(200).json({
            data: cursoBorrado,
            message: 'curso borrada con éxito'
        });
    } catch (err) {
        next(err);
    }

})

router.put('/:facultadId/grado/:gradoId/modificarcurso', async function (req, res, next) {
    const {body: nuevoCurso} = req;
    const  {facultadId}  = req.params;
    const  {gradoId}  = req.params;
    //const nuevoCurso = {curso: "adios", id: "12345"};
    

    try {
        const cursoActualizado = await BibliotecaService.actualizarCurso(facultadId, gradoId, nuevoCurso);

        res.status(200).json({
            data: cursoActualizado,
            message: 'curso actualizado con éxito'
        });
    } catch (err) {
        next(err);
    }

})



//para mostrar asignaturas

router.get('/:facultadId/paginagrados/:gradoId/paginacursos/:cursoId/paginaasignaturas', async (req, res, next) => {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 
    const {cursoId}  = req.params; 

    try {
      const asignaturas = await  BibliotecaService.getAsignaturas(facultadId, gradoId, cursoId);
      res.status(200).json(
          {
              data: asignaturas,
              message: 'asignaturas devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });


  router.get('/:facultadId/getgrado/:gradoId/getcurso/:cursoId/getasignatura/:asignaturaId', async function (req, res, next) {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 
    const {cursoId}  = req.params; 
    const {asignaturaId}  = req.params; 

    try {
        const asignatura = await BibliotecaService.getAsignatura(facultadId, gradoId, cursoId, asignaturaId);
        res.status(200).json({
            data: asignatura,
            message: 'asignatura devuelto'
        });
    } catch (err) {
        next(err);
    }
})


router.post('/:facultadId/grados/:gradoId/cursos/:cursoId/nuevasignatura', async(req, res, next) => { 
    const {body: nuevaAsignatura} = req; 
    const {facultadId} = req.params;
    const {gradoId} = req.params;
    const {cursoId} = req.params;


    //lo creo yo por ahora artificialmente para hacer pruebas en servidor, luego tengo que borrar esto
    //const nuevaAsignatura = {asignatura: "asignaturaprueba", id: "12345"};

    const _id = nuevaAsignatura.id;
    nuevaAsignatura["_id"] = _id;
    nuevaAsignatura["listadoscitas"] = ["listado a borrar"];

    try {
      const nuevasignaturaadd = await  BibliotecaService.addAsignatura(nuevaAsignatura, facultadId, gradoId, cursoId);
      res.status(200).json(
          {
              message: 'asignatura añadida correctamente',
              nuevasignatura: nuevasignaturaadd
          }
      )
    } catch (err){
        next(err);
    }
  });


  router.delete('/:facultadId/grados/:gradoId/cursos/:cursoId/borrarasignatura/:asignaturaId', async function (req, res, next) { 
    const  {facultadId}  = req.params;
    const  {gradoId} =req.params;
    const  {cursoId} =req.params;
    const  {asignaturaId} =req.params;

    try {
        const asignaturaBorrado = await BibliotecaService.borrarAsignatura(facultadId, gradoId, cursoId, asignaturaId);

        res.status(200).json({
            data: asignaturaBorrado,
            message: 'asignatura borrada con éxito'
        });
    } catch (err) {
        next(err);
    }

})


router.put('/:facultadId/grado/:gradoId/curso/:cursoId/modificarasignatura', async function (req, res, next) {
    const {body: nuevaAsignatura} = req;
    const  {facultadId}  = req.params;
    const  {gradoId}  = req.params;
    const  {cursoId}  = req.params;
    //const nuevaAsignatura = {asignatura: "prueba", id: "12345"};
    

    try {
        const asignaturaActualizado = await BibliotecaService.actualizarAsignatura(facultadId, gradoId, cursoId , nuevaAsignatura);

        res.status(200).json({
            data: asignaturaActualizado,
            message: 'asignatura actualizada con éxito'
        });
    } catch (err) {
        next(err);
    }

})




//mostrar listas:

router.get('/:facultadId/paginagrados/:gradoId/paginacursos/:cursoId/paginaasignaturas/:asignaturaId/paginalistas', async (req, res, next) => {
    const {facultadId} = req.params;
    const {gradoId}  = req.params; 
    const {cursoId}  = req.params; 
    const {asignaturaId}  = req.params; 

    try {
      const listas = await  BibliotecaService.getListas(facultadId, gradoId, cursoId, asignaturaId);
      res.status(200).json(
          {
              data: listas,
              message: 'listas bibliográficas devueltos con éxito'
          }
      )
    } catch (err){
        next(err);
    }
  });

  router.post('/:facultadId/grados/:gradoId/cursos/:cursoId/asignaturas/:asignaturaId/nuevalista', async(req, res, next) => { 
    const {body: nuevaLista} = req; 
    const {facultadId} = req.params;
    const {gradoId} = req.params;
    const {cursoId} = req.params;
    const {asignaturaId} = req.params;


    //lo creo yo por ahora artificialmente para hacer pruebas en servidor, luego tengo que borrar esto
    //const nuevaLista = {name: "prueba", id: "12398", url: "upsa.es" , ejemplares: "1"};

    const _id = nuevaLista.id;
    nuevaLista["_id"] = _id;

    try {
      const nuevalistaadd = await  BibliotecaService.addLista(nuevaLista, facultadId, gradoId, cursoId, asignaturaId);
      res.status(200).json(
          {
              message: 'lista bibliográfica añadida correctamente',
              nuevalista: nuevalistaadd
          }
      )
    } catch (err){
        next(err);
    }
  });


  router.delete('/:facultadId/grados/:gradoId/cursos/:cursoId/asignaturas/:asignaturaId/borrarlistado/:listaId', async function (req, res, next) { 
    const  {facultadId}  = req.params;
    const  {gradoId} =req.params;
    const  {cursoId} =req.params;
    const  {asignaturaId} =req.params;
    const  {listaId} =req.params;

    try {
        const listaBorrado = await BibliotecaService.borrarLista(facultadId, gradoId, cursoId, asignaturaId, listaId);

        res.status(200).json({
            data: listaBorrado,
            message: 'lista borrada con éxito'
        });
    } catch (err) {
        next(err);
    }

})


router.put('/:facultadId/grado/:gradoId/curso/:cursoId/asignatura/:asignaturaId/modificarlista', async function (req, res, next) {
    const {body: nuevaLista} = req;
    const  {facultadId}  = req.params;
    const  {gradoId}  = req.params;
    const  {cursoId}  = req.params;
    const  {asignaturaId} =req.params;
    //const nuevaLista = {name: "listapruebafinal", id: "12345"};
    

    try {
        const listaActualizada = await BibliotecaService.actualizarLista(facultadId, gradoId, cursoId, asignaturaId , nuevaLista);

        res.status(200).json({
            data: listaActualizada,
            message: 'lista actualizada con éxito'
        });
    } catch (err) {
        next(err);
    }

})


}


module.exports = bibliotecaAPI;
