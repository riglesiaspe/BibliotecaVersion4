
//const port = 3001;
const { config } = require('./config/index');

/*
if (process.env.NODE_ENV === 'development') {
    app.use((req, res, next) => {
         res.header('Access-Control-Allow-Origin', '');
         res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
        next();
         app.options('', (req, res) => {
               res.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS');
              res.send();
      });
   });
 }
*/
 

/*
var http = require('http');
var server = http.createServer( function(req, res){
    res.end('hola mundo')
});
server.listen('8080')
*/
const express = require('express');
const app = express();
const cors = require('cors');
app.use(express.static('dist/BibliotecaServicios2'));

//const { config } = require('./config/index');
const bibliotecaAPI = require('./routes/facultades');
const corsOptions = { origin : ["http://localhost:4200", "https://bibliotecacliente.vercel.app"]}; 
app.use(cors());

app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({extended: false}));
bibliotecaAPI(app);

/*
app.listen(port, () => {
    console.log(`servidor escuchando en ${port}`);
})
*/

app.listen(config.port, () => {
    console.log(`servidor escuchando en ${config.port}`);
})


/*
app.get('/', (req, res) => {
    res.send('hola mundo')
})
app.listen('8080')
*/