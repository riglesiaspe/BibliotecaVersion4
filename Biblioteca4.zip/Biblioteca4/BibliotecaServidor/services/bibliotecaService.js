const MongoLib = require('../lib/mongo');

class bibliotecaService {

    constructor(){
        this.collection = 'facultades';
        this.collectiongrados ='grados';
        this.mongoDB = new MongoLib();
    }

    async getFacultades() {
        const facultades = await this.mongoDB.getFacultades(this.collection);
        return facultades || [];
    }

    async getFacultad(facultadId){
        const facultad = await this.mongoDB.getFacultad(this.collection, facultadId);
        return facultad || [];
    }

    async addFacultad(facultad){
        const facultadCreadaId = await this.mongoDB.addFacultad(this.collection, facultad);
        return facultadCreadaId || [];
    }
    async actualizarFacultad( facultadId, facultad = {}){
        const facultadActualizadaId = await this.mongoDB.actualizarFacultad(this.collection, facultadId, facultad);
        return facultadActualizadaId || [];
    }

    async borrarFacultad( facultadId ){
        const facultadBorradaId = await this.mongoDB.borrarFacultad(this.collection, facultadId);
        return facultadBorradaId || [];
    }





    async getGrados( facultadId ) {
        //obtengo la facultad de la que tengo que obtener los grados
        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        //const grados = await this.mongoDB.getGrados(this.collection,this.collectiongrados, facultadId);
        return grados || [];
    }

    async getGrado(facultadId, gradoId){
        const facultad = await this.getFacultad(facultadId);
        const grado = await this.mongoDB.getGrado(facultad, gradoId);
        return grado || [];
    }

    async addGrado(grado, facultadId){
        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const gradoCreadoId = await this.mongoDB.addGrado(this.collection, grado, facultadId, grados, facultad);
        return gradoCreadoId || [];
    }

    async borrarGrado( facultadId, gradoId ){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const gradoBorradoId = await this.mongoDB.borrarGrado(this.collection, facultadId, gradoId, grados, facultad);
        return gradoBorradoId || [];
    }

    async actualizarGrado( facultadId, nuevoGrado){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const gradoActualizadoId = await this.mongoDB.actualizarGrado(this.collection, facultadId, nuevoGrado, grados, facultad);
        return gradoActualizadoId || [];
    }






    async getCursos( facultadId , gradoId) {
        //obtengo la facultad de la que tengo que obtener los grados
        const grado = await this.getGrado(facultadId, gradoId); 
        const cursos = await this.mongoDB.getCursos(grado);

        return cursos || [];
    }

    async getCurso(facultadId, gradoId, cursoId){
        const grado = await this.getGrado(facultadId, gradoId);
        const curso = await this.mongoDB.getCurso(grado, cursoId);
        return curso || [];
    }

    async addCurso(nuevocurso, facultadId, gradoId){
        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const cursoCreadoId = await this.mongoDB.addCurso(this.collection, nuevocurso, facultadId, gradoId, facultad, grados, grado, cursos);
        return cursoCreadoId || [];
    }



    async borrarCurso( facultadId, gradoId, cursoId ){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);


        const cursoBorradoId = await this.mongoDB.borrarCurso(this.collection, facultadId, gradoId, cursoId, facultad, grados, cursos);
        return cursoBorradoId || [];
    }

    async actualizarCurso( facultadId, gradoId, nuevoCurso){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const cursoActualizadoId = await this.mongoDB.actualizarCurso(this.collection, facultadId, gradoId , nuevoCurso, facultad, grados, cursos);
        return cursoActualizadoId || [];
    }






    async getAsignaturas( facultadId , gradoId, cursoId) {
        //obtengo el curso del que tengo que obtener las asignaturas
        const curso = await this.getCurso(facultadId, gradoId, cursoId); 
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        return asignaturas || [];
    }

    async getAsignatura(facultadId, gradoId, cursoId, asignaturaId){
        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignatura = await this.mongoDB.getAsignatura(curso, asignaturaId);
        return asignatura || [];
    }

    async addAsignatura(nuevasignatura, facultadId, gradoId, cursoId){
        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        const asignaturaCreadaId = await this.mongoDB.addAsignatura(this.collection, nuevasignatura, facultadId, gradoId, cursoId, facultad, grados, grado, cursos, curso, asignaturas);
        return asignaturaCreadaId || [];
    }

    async borrarAsignatura( facultadId, gradoId, cursoId, asignaturaId ){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);


        const asignaturaBorradaId = await this.mongoDB.borrarAsignatura(this.collection, facultadId, gradoId, cursoId, asignaturaId, facultad, grados, cursos, asignaturas);
        return asignaturaBorradaId || [];
    }


    async actualizarAsignatura( facultadId, gradoId, cursoId,  nuevaAsignatura){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        const asignaturaActualizadoId = await this.mongoDB.actualizarAsignatura(this.collection, facultadId, gradoId , cursoId, nuevaAsignatura, facultad, grados, cursos, asignaturas);
        return asignaturaActualizadoId || [];
    }






    async getListas( facultadId , gradoId, cursoId, asignaturaId) {
        //obtengo la asignatura del que tengo que obtener las listas 
        const asignatura = await this.getAsignatura(facultadId, gradoId, cursoId, asignaturaId); 
        const listas = await this.mongoDB.getListas(asignatura);

        return listas || [];
    }

    async addLista(nuevalista, facultadId, gradoId, cursoId, asignaturaId){
        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        const asignatura = await this.getAsignatura(facultadId, gradoId, cursoId, asignaturaId);
        const listados = await this.mongoDB.getListas(asignatura);

        const listaCreadaId = await this.mongoDB.addLista(this.collection, nuevalista, facultadId, gradoId, cursoId, asignaturaId, facultad, grados, grado, cursos, curso, asignaturas, asignatura, listados);
        return listaCreadaId || [];
    }



    async borrarLista( facultadId, gradoId, cursoId, asignaturaId , listaId){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        const asignatura = await this.getAsignatura(facultadId, gradoId, cursoId, asignaturaId);
        const listados = await this.mongoDB.getListas(asignatura);


        const listaBorradaId = await this.mongoDB.borrarLista(this.collection, facultadId, gradoId, cursoId, asignaturaId,listaId, facultad, grados, cursos, asignaturas, listados);
        return listaBorradaId || [];
    }

    async actualizarLista( facultadId, gradoId, cursoId, asignaturaId , nuevaLista){

        const facultad = await this.getFacultad(facultadId);
        const grados = await this.mongoDB.getGrados(facultad);

        const grado = await this.getGrado(facultadId, gradoId);
        const cursos = await this.mongoDB.getCursos(grado);

        const curso = await this.getCurso(facultadId, gradoId, cursoId);
        const asignaturas = await this.mongoDB.getAsignaturas(curso);

        const asignatura = await this.getAsignatura(facultadId, gradoId, cursoId, asignaturaId);
        const listados = await this.mongoDB.getListas(asignatura);

        const listaActualizadaId = await this.mongoDB.actualizarLista(this.collection, facultadId, gradoId , cursoId,asignaturaId, nuevaLista, facultad, grados, cursos, asignaturas, listados);
        return listaActualizadaId || [];
    }
    
}

module.exports = bibliotecaService